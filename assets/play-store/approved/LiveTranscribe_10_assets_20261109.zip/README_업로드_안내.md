# LiveTranscribe Google Play 등록용 이미지 10종

- `assets/play-store/ko-KR/icon.png` (512×512)
- `assets/play-store/ko-KR/featureGraphic.png` (1024×500)
- `assets/play-store/ko-KR/01-home.png` ~ `08-settings.png` (1080×1920)
- `manifest.json`에 SHA-256 및 실제 캡처 출처가 기록되어 있습니다.

## 주의

1. **Play Console에는 아직 반영되지 않았습니다.**
2. 실제 화면은 PR #32의 Android 에뮬레이터 캡처이며, 오디오 추론 성공을 보여주지 않습니다.
3. 테스트용 가짜 번역 기록 UI는 사용하지 않았습니다.
4. 검증한 뒤 프로젝트 GitHub 저장소의 `assets/play-store/ko-KR/` 경로에 PNG 및 manifest를 배치해야 합니다.
5. `main` CI가 성공한 뒤 GitHub Actions → `Play Korean store listing` → `Run workflow`, `mode=check` 확인 후 `mode=apply`를 실행합니다. 기본 설정은 심사 제출 없이 Console 변경사항 대기 상태입니다.
6. `mode=apply` 성공 시에도 Console 화면에서 이미지 및 실제 등록 상태를 검증해야 합니다.
